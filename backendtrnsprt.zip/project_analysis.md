# Ram Transport Management System - Project Analysis & Implementation Status

This document provides a comprehensive audit of the Ram Transport Management System, analyzing both the **React Frontend** (`Transport-Frontend-main`) and the **Node.js/Express Backend** (`Transport_Management_System-main`). It details which features are fully implemented, which are partially implemented, and which remain pending, alongside explanations of how each module works under the hood.

---

## 1. System Architecture & Tech Stack

### Frontend Architecture
* **Core Framework:** React 18 (Vite-powered development and bundler).
* **Routing:** `react-router-dom` (v6) with declarative routes and a custom `<ProtectedRoute>` wrapper that validates JWT presence.
* **Styling:** Bootstrap 5 with FontAwesome 7 icon packs and custom global styling (`src/styles.css`).
* **State & APIs:** Standard React Hooks (`useState`, `useEffect`, `useMemo`) combined with a fetch-based custom API client (`src/api.js`) targeting `http://localhost:5000/api/v1`.
* **Push Notifications:** Firebase Cloud Messaging client-side service worker (`firebase-messaging-sw.js` and `fcm.js`).

### Backend Architecture
* **Runtime & Framework:** Node.js with Express.js.
* **Database:** MongoDB configured using Mongoose models.
* **Logging:** Winston logger mapping output to `logs/app.log` and the system terminal console.
* **Security & Auth:** JWT (JSON Web Tokens) with a custom `protect` and role-based `authorize('admin', 'driver')` middleware. Driver account verification (`isVerified` flag) is enforced at login.
* **Uploads & Image Processing:** Multistage uploads via `multer` (in-memory storage) and custom conversion/compression to high-performance `.webp` format using `sharp`.
* **Mail Server:** NodeMailer transport integration for email delivery (OTP verification code).
* **Push Notifications:** Firebase Admin SDK integration supporting single-target and multicast payloads.

---

## 2. Database Models Schema (`Models/`)

### 1. User Model (`UserModel.js`)
Stores Admins and Drivers.
* **Fields:** `name` (String), `email` (String, unique), `password` (String, hashed), `role` (enum: `'admin'`, `'driver'`), `phone` (String), `isVerified` (Boolean, default `false`), `isAvailable` (Boolean, default `true` - driver availability), `fcmToken` (String), `otp` (String), `otpExpire` (Date), `resetPasswordToken` (String), `resetPasswordExpire` (Date), `createdAt` (Date).
* **Driver Specific Fields:** `license` (String, filepath to license image), `vehicleNumber` (String), `experience` (Number), `address` (String), `emergencyContact` (String).

### 2. Trip Model (`TripModel.js`)
Tracks the lifecycle, locations, pricing, and driver assignments of each trip.
* **Fields:** `pickupLocation` (String), `dropLocation` (String), `customerName` (String), `customerPhone` (String), `driverId` (ObjectId ref User), `status` (enum: `'CREATED'`, `'ASSIGNED'`, `'ACCEPTED'`, `'EN_ROUTE'`, `'COMPLETED'`, `'CANCELLED'`), `distance` (Number, in km), `fare` (Number), `driverEarning` (Number), `startTime` (Date), `endTime` (Date), `cancellationReason` (String), `createdBy` (ObjectId ref User - creator admin), `createdAt` (Date).

### 3. Payment Model (`PaymentModel.js`)
Logs transaction states for customer collections and driver payouts.
* **Fields:** `tripId` (ObjectId ref Trip), `driverId` (ObjectId ref User), `amount` (Number), `paymentType` (enum: `'CUSTOMER_PAYMENT'`, `'DRIVER_PAYOUT'`), `paymentMethod` (enum: `'CASH'`, `'CARD'`, `'UPI'`, `'BANK_TRANSFER'`), `status` (enum: `'PENDING'`, `'COMPLETED'`, `'FAILED'`), `transactionId` (String), `processedBy` (ObjectId ref User - admin), `createdAt` (Date).

### 4. Notification Model (`NotificationModel.js`)
Logs manual and broadcast notifications sent within the system.
* **Fields:** `title` (String), `description` (String), `targetType` (enum: `'ALL'`, `'SELECTED'`), `recipientDriverId` (ObjectId ref User), `createdBy` (ObjectId ref User), `createdAt` (Date).

### 5. Fare Configuration Model (`FareConfigModel.js`)
Stores dynamic parameters for automated distance-based fare calculations.
* **Fields:** `baseFare` (Number, default `50`), `perKmRate` (Number, default `15`), `commissionRate` (Number, default `20` for 20%), `updatedAt` (Date).

---

## 3. Admin Panel - Implementation Status

### 1. Dashboard
* **Status:** **Partially Completed**
* **How it works:** 
  * The frontend calls `adminApi.getTrips()` and `adminApi.getAllDrivers()`, performing in-memory aggregations to show totals.
  * Displays: **Total Trips**, **Completed Trips**, **Total Drivers**, and **Active (Verified) Drivers**.
  * Displays a list of recent trips showing pickup/drop points, customer details, assigned driver, status, and creation date.
* **Pending / Gaps:**
  * The backend supports calculations for **Total Revenue** and **Commission Earnings**, but these are **not rendered** on the React dashboard cards.
  * The layout lacks visual charts or analytics graphs for revenue performance.

### 2. Driver Management
* **Status:** **Completed** (with minor frontend gaps)
* **How it works:**
  * **All Drivers:** Table displaying name, email, phone, vehicle, experience, status, and registration date.
  * **Add/Edit Driver:** Modal form supporting text parameters and a license image upload. The backend uses `multer` to capture the file, then `sharp` processes it into a compressed `.webp` saved to the local server storage path.
  * **Activate/Deactivate:** Toggles the `isVerified` status of a driver. A deactivated driver cannot log in.
* **Pending / Gaps:**
  * **Driver Documents Check:** While drivers can upload a license file, there is **no preview or download utility** in the driver management UI to inspect the license image file.
  * **Driver Performance:** There is no sub-panel or link to inspect individual driver trip histories (you can only search for their name in the main Trip Management search bar).

### 3. Trip Management
* **Status:** **Completed** (with minor UI refinements pending)
* **How it works:**
  * **All Trips:** Displays a card grid containing pickup/drop points, customer data, distance, fare, driver earnings, and assigned drivers. Includes a search input filtering by locations, customer names, or status.
  * **Create Trip:** Modal form to create a manual trip.
  * **Assign Driver:** Admin inputs estimated distance (km), selects an available driver from a dropdown list, and submits. The backend updates the trip status to `'ASSIGNED'`, calculates initial values, and triggers a push notification to the driver.
  * **Delete/Edit Trip:** Allows full CRUD operations.
* **Pending / Gaps:**
  * The frontend does not have separate views or tabs for *Assigned*, *Ongoing*, *Completed*, or *Cancelled* trips. Instead, they are all mixed in one list, and you must manually search the status (e.g. typing "COMPLETED") to filter them.

### 4. Billing & Payments
* **Status:** **Pending on Frontend** (Completed on Backend)
* **How it works (Backend):**
  * Express endpoints under `/api/v1/payments`:
    * `GET /`: Lists all payment records with filters (driver, status, search, date range).
    * `GET /stats`: Computes Total Collections, Total Payouts, Pending Driver Payouts count/sum, and Estimated Company Net Revenue.
    * `POST /collect`: Logs a `'CUSTOMER_PAYMENT'` for a completed trip.
    * `POST /payout`: Logs a `'DRIVER_PAYOUT'` of driver earnings for a completed trip.
* **Pending / Gaps:**
  * **No Frontend UI:** The frontend route `/admin/billing_payment` simply loads the `<Placeholder title="billing-and-payment" />` component. Admin cannot view driver earnings, process payments, or generate invoices in the UI.

### 5. Reports & Analytics
* **Status:** **Pending on Frontend** (Completed on Backend)
* **How it works (Backend):**
  * `GET /api/v1/trips/reports` allows filtering by start/end dates. It returns total trips, completed/cancelled/active counts, financial summaries (total revenue, total driver earnings, system commission), and a status breakdown.
* **Pending / Gaps:**
  * **No Frontend UI:** The frontend route `/admin/reports` maps to the `<Placeholder title="reports" />` component. Date filtering, CSV/Excel exporting, and custom charts are missing from the interface.

### 6. Notifications
* **Status:** **Pending on Frontend** (Completed on Backend)
* **How it works (Backend):**
  * `POST /api/v1/notifications` accepts `title`, `description`, `targetType` (`'ALL'` or `'SELECTED'`), and optional `recipientDriverId`. It saves to the DB and triggers Firebase Admin messaging.
  * `GET /api/v1/notifications/admin` retrieves notification history.
* **Pending / Gaps:**
  * **No Frontend UI:** The route `/admin/notification` is a `<Placeholder>` component. Admins cannot send messages, choose targets, or view notification histories in the React panel.

### 7. Settings
* **Status:** **Partially Completed**
* **How it works:**
  * **Fare Settings:** `AdminSettings` component displays dynamic configuration inputs (Base Fare, Per KM Rate, Commission Rate) and updates them on the backend via `/api/v1/trips/fare-config`.
* **Pending / Gaps:**
  * **Profile Update:** The sidebar lists a "Profile" route `/admin/profile`, but it redirects to the `<Placeholder title="profile" />` component. Admin cannot update personal information or credentials through a dedicated profile page.

---

## 4. Driver Panel - Implementation Status

### 1. Dashboard
* **Status:** **Pending on Frontend** (Completed on Backend)
* **How it works (Backend):**
  * `GET /api/v1/trips/dashboard` for a driver role returns total trips, completed, cancelled, active trip counts, total earnings, the current active trip object, and a list of 5 recent trips.
* **Pending / Gaps:**
  * **No Dashboard Page:** The Driver React panel does not define a dashboard route or sidebar link. The homepage redirects straight to `/driver/my_trips`. Shows no today's trips summary, active trip widget, or total earnings banner.

### 2. My Trips (Manage Trip Workflow)
* **Status:** **Completed**
* **How it works:**
  * Renders a list of trips assigned to the logged-in driver.
  * **State Transitions (Interactive buttons):**
    * **Accept Trip:** Status changes from `'ASSIGNED'` to `'ACCEPTED'`.
    * **Start Trip:** Status changes from `'ACCEPTED'` to `'EN_ROUTE'`.
    * **Complete Trip:** Status changes to `'COMPLETED'`. The backend automatically calculates the dynamic customer fare and driver earnings using the current `FareConfig` parameters and writes them to the DB.
    * **Cancel:** Toggles status to `'CANCELLED'`.
* **Pending / Gaps:**
  * There are no filter tabs. All status cards (Completed, Assigned, Cancelled) load in a single list.

### 3. Availability / Status
* **Status:** **Pending on Frontend** (Completed on Backend)
* **How it works (Backend):**
  * `PATCH /api/v1/drivers/availability` accepts a boolean `isAvailable` and updates the driver's availability status.
* **Pending / Gaps:**
  * **No UI Element:** Driver lacks an Online/Offline switch, availability toggle, or status logs in the React panel.

### 4. Earnings
* **Status:** **Pending on Frontend** (Completed on Backend)
* **How it works (Backend):**
  * `GET /api/v1/trips/my-earnings` calculates total lifetime earnings, today's earnings, and returns a detailed list of completed trips (date, distance, fare, driver earnings).
* **Pending / Gaps:**
  * **No Frontend UI:** The sidebar link `/driver/my_earnings` opens the `<Placeholder title="my-earnings" />` component. Driver cannot view daily/weekly/monthly statistics or payout history.

### 5. Notifications
* **Status:** **Pending on Frontend** (Completed on Backend)
* **How it works (Backend):**
  * `GET /api/v1/notifications/driver` returns driver-specific (SELECTED) and broadcast (ALL) notifications.
* **Pending / Gaps:**
  * **No Notification UI:** Driver Panel does not display notifications in-app.

### 6. Profile
* **Status:** **Pending on Frontend** (Completed on Backend)
* **How it works (Backend):**
  * CRUD endpoints on `/drivers/:id` allow updating user info, and `/auth/updatepassword` handles password changes.
* **Pending / Gaps:**
  * **No Profile Page:** No sidebar link or page exists. Drivers cannot edit vehicle specifications, update documents, check details, or change their passwords via the UI.

---

## 5. Summary Matrix: Implemented vs. Pending Features

| Panel | Module | Feature | Backend Status | Frontend Status |
| :--- | :--- | :--- | :--- | :--- |
| **Admin** | **Dashboard** | Total Drivers, Completed/Active Trips | Completed | Completed |
| **Admin** | **Dashboard** | Total Revenue, Recent Activities | Completed | **Pending** (Revenue not shown) |
| **Admin** | **Driver Management** | View, Add, Edit, Delete Drivers | Completed | Completed |
| **Admin** | **Driver Management** | Active/Inactive Toggle (`isVerified`) | Completed | Completed |
| **Admin** | **Driver Management** | Document Verification Check | Completed | **Pending** (No file preview in UI) |
| **Admin** | **Driver Management** | Driver Performance History | Completed | **Pending** (No detailed driver stats) |
| **Admin** | **Trip Management** | Manual Create, Edit, Delete | Completed | Completed |
| **Admin** | **Trip Management** | Driver Assignment & Distance | Completed | Completed |
| **Admin** | **Trip Management** | Filtered Tabs (Assigned, Ongoing, etc.)| Completed | **Pending** (Unified card view only) |
| **Admin** | **Billing & Payments**| View Earnings, Pending/Done Payouts | Completed | **Pending** (Placeholder page) |
| **Admin** | **Billing & Payments**| Generate Invoice, commission settings | Completed | **Pending** (Placeholder page) |
| **Admin** | **Reports & Analytics**| Trip, Driver, Revenue Reports & Export | Completed | **Pending** (Placeholder page) |
| **Admin** | **Notifications** | Send single / Broadcast notifications | Completed | **Pending** (Placeholder page) |
| **Admin** | **Settings** | Fare Configuration (Base, Per Km, Comm) | Completed | Completed |
| **Admin** | **Settings** | Admin Profile Update | Completed | **Pending** (Placeholder page) |
| **Driver**| **Dashboard** | Today's trips, active trip, earnings | Completed | **Pending** (No dashboard route) |
| **Driver**| **My Trips** | Trip Lifecycle transitions (Accept/Start/Done)| Completed | Completed |
| **Driver**| **Availability** | Go Online / Offline | Completed | **Pending** (No toggle button in UI) |
| **Driver**| **Earnings** | Daily, weekly, monthly logs & history | Completed | **Pending** (Placeholder page) |
| **Driver**| **Notifications** | Trip status updates and custom alerts | Completed | **Pending** (No in-app view) |
| **Driver**| **Profile** | View/Edit details, change password | Completed | **Pending** (No profile route) |

---

## 6. How It Works: Core Workflows

### A. Driver Registration & Verification Workflow
```mermaid
sequenceDiagram
    actor Driver
    actor Admin
    participant Server as Backend Server
    participant DB as MongoDB
    
    Driver->>Server: Register (Name, Phone, Vehicle, Upload License Image)
    Note over Server: Multer extracts file buffer<br/>Sharp converts image to WebP<br/>Saves WebP to /uploads
    Server->>DB: Create User (role: driver, isVerified: false)
    Note over Admin: Admin opens Driver Management
    Admin->>Server: Toggle Activate Driver (ID)
    Server->>DB: Update User (isVerified: true)
    Note over Driver: Driver logs in successfully
```

### B. Trip Lifecycle & Fare Calculation Workflow
```mermaid
sequenceDiagram
    actor Admin
    actor Driver
    participant Server as Backend Server
    participant DB as MongoDB
    
    Admin->>Server: Create Trip (Pickup, Drop, Customer Info)
    Server->>DB: Save Trip (status: CREATED)
    Admin->>Server: Assign Driver (Driver ID, Distance in km)
    Server->>DB: Update Trip (driverId, distance, status: ASSIGNED)
    Server->>Driver: Trigger FCM Push Notification ("New Trip Assigned")
    Driver->>Server: Accept Trip
    Server->>DB: Update Trip (status: ACCEPTED)
    Driver->>Server: Start Trip (pickup point reached)
    Server->>DB: Update Trip (status: EN_ROUTE, startTime: Now)
    Driver->>Server: Complete Trip (dropoff point reached)
    Note over Server: Fetches active FareConfig<br/>Fare = BaseFare + (Distance * PerKmRate)<br/>Earning = Fare - (Fare * CommissionRate)
    Server->>DB: Update Trip (status: COMPLETED, endTime: Now, fare, driverEarning)
    Server->>Admin: Trigger Multicast Push Notification ("Trip Completed")
```
